<div style='width: 100%; display: flex; justify-content: center;'>
	<h2>Welcome to My Activity</h2>
</div><?php /**PATH C:\Users\tanta\eclipse-cst323\activity1\resources\views/layouts/header.blade.php ENDPATH**/ ?>