<footer style='width: 100%; display: flex; justify-content: center;'>
	<h5>Copyright @2022 TannerRay</h5>
</footer>