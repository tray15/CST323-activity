<div style='width: 100%; display: flex; justify-content: center;'>
	<h2>Welcome to My Activity</h2>
</div>