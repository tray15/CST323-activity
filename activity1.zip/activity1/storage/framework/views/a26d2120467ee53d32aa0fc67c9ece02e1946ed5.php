

<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-dark navbar-expand" style="background-color: #42cef5;">
    <div class="container">
        <div class=" collapse navbar-collapse justify-content-center" id="navbarText">
            <a class="navbar-brand text-center" href="/index"></a>
        </div>
    </div>
</nav>
<div>
    <div class="container">
      <div class="row">
        <div class="col-md-12 align-self-center" style="margin: 100px 0px 0px 0px;">
          <h2 class="text-center" style="margin: 0px 0px 30px;">All users</h2>
        </div>
      </div>
    </div>
</div>
<div class="container">
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title">Users</h4>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table">
            <thead class=" text-primary">
              <th>ID</th>
              <th>Username</th>
            </thead>
            <tbody>
              <!--fetch table data -->
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($row->id); ?></td>
                <td><?php echo e($row->username); ?></td>
				<td>
                  <a href="allUsers/editUser/<?php echo e($row->id); ?>" class="btn btn-success">EDIT</a>
                </td>
                <td>
                  <form action="allUsers/deleteUser/<?php echo e($row->id); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-danger">DELETE</button>
                  </form>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tanta\eclipse-cst323\activity1\resources\views/allUsers.blade.php ENDPATH**/ ?>