

<?php $__env->startSection('title'); ?>
			Edit User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-dark navbar-expand" style="background-color: #42cef5;">
    <div class="container">
        <div class=" collapse navbar-collapse justify-content-center" id="navbarText">
            <a class="navbar-brand text-center" href="/index"></a>
        </div>
    </div>
</nav>
<div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 align-self-center" style="margin: 100px 0px 0px 0px;">
                <h2 class="text-center" style="margin: 0px 0px 30px;">Modify User</h2>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form action="/activity1/public/allUsers/doUserUpdate/<?php echo e($user->id); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <div class="row d-flex justify-content-center">
                            <div class="col-md-8">
                                <div class="form-group" style="text-align:left;">
                                    <label>Username</label>
                                    <input type="text" name="username" value="<?php echo e($user->username); ?>" class="form-control">
                                </div>
                            </div>
                        </div>
                        <button type="Submit" class="btn btn-success">Submit</button>
                        <a href="/activity1/public/allUsers" class="btn btn-danger">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tanta\eclipse-cst323\activity1\resources\views/userEdit.blade.php ENDPATH**/ ?>